package day06;
import java.util.Scanner;
public class Add {

	public static void main(String[] args) {
		// 2개의 정수를 입력 받아서 더한 결과를 출력하시오.
		
		Scanner sc = new Scanner(System.in);
		System.out.println("정수2개를 입력하세요.");
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		
		int sum = n1 + n2;
		
		System.out.println("입력한 정수의 합은"+ sum+"입니다.");

	}

}
