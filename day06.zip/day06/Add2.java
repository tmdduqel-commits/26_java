package day06;
import java.util.Scanner;
public class Add2 {

	public static void main(String[] args) {
		// 2개의 실수를 입력 받아서 곱한 결과를 출력하시오.
		
		Scanner sc = new Scanner(System.in);
		System.out.println("실수2개를 입력하세요.");
		double n1 = sc.nextDouble();
		double n2 = sc.nextDouble();
		
		double q = n1 * n2;
		
		System.out.println("입력한 실수의 곱은"+ q+"입니다.");

	}

}
