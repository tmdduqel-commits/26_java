package day06;
import java.util.Scanner;
public class Method2 {

	//2개의 정수를 입력 받아서 최대값을 반환하는 max()메소드를 정의하고 호출 한 후 결과를 출력하시오.
	
	public static void max() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("정수 2개 입력");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		
		if(num1 > num2) {
			System.out.println(num1);
		}else {
			System.out.println(num2);
		}
				
		
	}
	
	
	public static void main(String[] args) {
		max();
		
		
	}
}




