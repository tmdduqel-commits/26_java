package day06;
import java.util.Scanner;
public class Method3 {

	// 2개의 정수와 1개의 문자열을 입력 받아서 4칙연산을 수행하는 계산기 메소드 add(), sub(), mul(), div()
	// 정의하시오
	// 문자열이 + 이면, add() 호출, -이면 sub()호출, *이면 mul()호출, / 이면 div() 호출
	
	public static int add(int a,int b,String s) {
			
		
		return a+b;
		
	}
	
	public static int sub(int a,int b,String s) {
		
		
		return a-b;
		
	}
	
	public static int mul(int a,int b,String s) {
		
		
		return a*b;
		
	}
	
	public static int div(int a,int b,String s) {
		
		
		return a/b;
		
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a, b;
		String s;
		
		System.out.println("정수2개입력");
		a = sc.nextInt();
		b = sc.nextInt();
		System.out.println("연산 부호 입력");
		s = sc.next();
		
		
		
		switch(s) {
		case "+":
			System.out.println(add(a,b,s));		
		break;
		
		case "-":
			System.out.println(sub(a,b,s));	
			break;
			
		case "*":
			System.out.println(mul(a,b,s));		
			break;
			
		case "/":
			System.out.println(div(a,b,s));			
			break;
		default:
				break;
		}
		
		
	}
}




