package day04;
import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int balance = 10000;
		System.out.println("나이를 입력하세요");
		int age = sc.nextInt();
		
		if(age>=19) {
		balance -=1200;
		System.out.println("잔액:"+balance); 
		
		} else if(age>=13) {
			balance -= 720;
			System.out.println("잔액:"+balance); 
	}
		else if(age>=7) {
			balance -= 450;
			System.out.println("잔액:"+balance); 
		}
	}
}



