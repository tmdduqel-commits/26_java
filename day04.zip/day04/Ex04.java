package day04;

public class Ex04 {

	public static void main(String[] args) {
		
		// 1부터 100까지의 합을 계산하는 for 반복문 완성
		
		//for(초기식;조건식;증감식){실행문}
		
		int sum = 0;
		for(int i = 1; i <= 100;i++) {
			sum = sum + i;
			//System.err.print(i);
		}
		System.out.println(sum);
	}

}
