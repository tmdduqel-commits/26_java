package day04;

public class GuGudan {

	public static void main(String[] args) {
		//2중 중첩 for문 활용하기
		//2단부터 9단까지.. for문
		// 안쪽 *1,*2,*3...*9 ...for문
		
		
		for(int dan = 2; dan<=9;dan++) {
			for(int num = 1;num<=9;num++) {		//각 단의 구구단 출력
				System.out.print(dan+"*"+num + "=" + dan * num);	//구구셈 출력
				System.out.print("\t");
			}
			System.out.println();
		}
	}
}

