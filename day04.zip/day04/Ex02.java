package day04;
import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("필기점수를 입력하세요");
		int Fs = sc.nextInt();
		System.out.println("토익점수를 입력하세요");
		int Ts = sc.nextInt();
		
		if(Fs>=80 && Ts>=850) {
			System.out.println("합격");
		} else {
			System.out.println("불합격");
		}
		

	}

}
