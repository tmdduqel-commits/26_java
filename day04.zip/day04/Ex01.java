package day04;
import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("나이를 입력하세요");
		int age = sc.nextInt();
		
		if(age<18) {
			System.out.println("청소년 관람 불가");
		}else {
			System.out.println("재밌게보십쇼");
		}
		

	}

}
