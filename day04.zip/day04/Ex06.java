package day04;
import java.util.Scanner;
public class Ex06 {
	//5개 정수 입력 받아서 양수의 합을 구하시오.
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int sum = 0;
		System.out.println("정수를 입력하세요");
		for(int i = 1; i<=5;i++) {			
			int num = sc.nextInt();
			// 만약에 정수가 음수라면, 무시, 양수이면 합 추가
			if(num<0) {
				continue;
				
				}else {
					sum += num;				
			}			
		}
		System.out.println("양수의 합은 : "+ sum);

	}

}
