package day04;
import java.util.Scanner;
public class Ex07 {
	//무한반복해서 정수를 입력한 후, 음수가 입력되면 무한반복을 종료하고 누적의 합을 출력
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		System.out.println("정수를 입력하세요");
		while(true) {			
			int num = sc.nextInt();
			// 만약에 정수가 음수라면, 정지, 양수이면 합 추가
			if(num<0) {
				break;
				
				}else {
					sum += num;				
			}			
		}
		System.out.println("양수의 합은 : "+ sum);

	}

}
