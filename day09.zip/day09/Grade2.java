package day09;
import java.util.Scanner;
public class Grade2 {

	//속성
	String name;
	int score1, score2, score3;
	
	//인자 생성자
	public Grade2(String name, int score1, int score2, int score3) {
		this.name = name;
		this.score1 = score1;
		this.score2 = score2;
		this.score3 = score3;		
	}
	
	
	
	//메소드
	public String getName() {
		return name;
	}
	
	public int getAverage() {
		int sum = score1 + score2 + score3;
		int avg = sum / 3;
		return avg;
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("이름, 자바, 웹프로그래밍, 운영체제 순으로 점수 입력>>");
		String name = sc.next();
		int java = sc.nextInt();
		int web = sc.nextInt();
		int os = sc.nextInt();
		Grade2 st = new Grade2(name, java, web, os);
		System.out.println(st.getName() + "의 평균은 " + st.getAverage() + "입니다.");
		sc.close();
		
	}

}
