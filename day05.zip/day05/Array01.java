package day05;
import java.util.Scanner;
public class Array01 {

	public static void main(String[] args) {
		// 1차원 배열 선언
		int intArray[];
		// 배열 생성
		intArray = new int[5];		
		int intMax = 0;	//가장 큰 수 저장
		Scanner sc = new Scanner(System.in);
		// 양수 5개 입력 받아 배열에 저장 하고, 그 중 가장 큰 수 출력 하기
		
		System.out.println("5개 양수 입력하기");
		for(int i=0;i<intArray.length;i++) {
			intArray[i] = sc.nextInt();
			if(intArray[i] > intMax) {
				intMax = intArray[i]; // 최대값 변경
			}
			
		}
		System.out.println("가장 큰 수는 " + intMax + "입니다.");
		
		
		
		
		
		
		

	}

}
