package day05;
import java.util.Scanner;
public class Array02 {

	public static void main(String[] args) {
		// 1차원 배열 선언
		int intArray[];
		// 배열 생성
		intArray = new int[5];		
		int sum = 0;	
		Scanner sc = new Scanner(System.in);
		// 양수 5개 입력 받아 배열에 저장 하고, 평균 구하기
		
		System.out.println("5개 양수 입력하기");		
		
		for(int i=0;i<intArray.length;i++) {
			intArray[i] = sc.nextInt();
			
		}
		for(int i=0; i<intArray.length;i++) {
			sum +=intArray[i];
		}
		int avg = sum / intArray.length;
		System.out.println("평균은"+avg+"입니다.");
		
		
	}
}
