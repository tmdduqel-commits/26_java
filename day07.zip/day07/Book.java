package day07;
import java.util.Scanner;
public class Book {
	String title;
	String author;
	
	public Book(String t) {
		title = t; author = "작자미상";
	}
	
	public Book(String t, String a) {
		title = t; author = a;
	}
	
	public static void main(String[] args) {
		Book[] book = new Book[2];
		
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<book.length;i++) {
			System.out.println("제목>>");
			String title = sc.nextLine();
			System.out.println("저자>>");
			String author = sc.nextLine();
			book[i] = new Book(title, author);			
		}
		for(int i = 0; i<book.length;i++) {
			System.out.println("("+book[i].title + ","+book[i].author+")");
			
		sc.close();
		}
		
		
//		Book littlePrince = new Book("어린왕자", "생텍쥐페리");
//		Book loveStory = new Book("춘향전");		
//		System.out.println(littlePrince.title + "" + littlePrince.author);
//		System.out.println(loveStory.title + "" + loveStory.author);		
	}

}
