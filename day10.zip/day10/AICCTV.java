package day10;

class CCTV{
	private String resolution;	
	
	//생성자
	public CCTV(String resolution) {
		this.resolution = resolution;
		}
	
	//getter()
	public String getResolution() {
		return resolution;
		}
}

public class AICCTV extends CCTV {
	boolean facecheck;
	
	public AICCTV(String resolution, boolean facecheck) {
		super(resolution);
		this.facecheck = facecheck;
	}
	String re = super.getResolution();
	
	public void printInfo() {
		if(re.equals("FHD")) {
			System.out.println("CCTV는 FHD 급 해상도이며현재 얼굴 인식 작동 중");					
		}
		else {
			System.out.println("해상도가 낮습니다.");
		}
		
	}

	public static void main(String[] args) {
		AICCTV ai = new AICCTV("FHD", true); //"FHD" 급의 해상도로 얼굴 인식 활성화
		ai.printInfo();
	}

}
