package day14;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MyJFrame extends JFrame {
	
	// 생성자
	 public MyJFrame() {
		 this.setTitle("나만의 프레임");
		 Container con = getContentPane();
		 setLayout(new FlowLayout()); // 익명 클래스 
		 JButton btn = new JButton("소개");
		 con. add (btn);
		 JTextField jf;
		 con.add( jf = new JTextField(20));
		 JButton btn2 = new JButton("확인");
		 con. add (btn2);
		 // 익명클래스로 리스너 구현
		 btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object obj = (JButton)e.getSource();
				
				if(obj == btn) System.out.print("소개 버튼 클릭");
				//if(obj == btn)System.out.print(jf.getText());
			}
			 
		 });
		 btn2.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
				
					System.out.print(jf.getText());
					// 텍스트 필드 초기화
					jf.setText("");
				}
				 
			 });
		 setSize(300, 200);
		 setVisible(true);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 
	 }
	 
public static void main(String[] args) {
	new MyJFrame();

	}
}