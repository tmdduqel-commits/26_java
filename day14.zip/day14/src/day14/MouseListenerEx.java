package day14;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class MouseListenerEx extends JFrame{
	private JLabel la = new JLabel("Hello");
	
	public MouseListenerEx() {
		setTitle("Mouse 이벤트예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container con = getContentPane();
		con.addMouseListener(new MyMouseListener());
		
		con.setLayout(null);
		la.setSize(50, 20);
		la.setLocation(30, 30);
		con.add(la);
		
		setSize(250, 250);
		setVisible(true);
	
	}
	class MyMouseListener extends MouseAdapter{
		public void mousePressed(MouseEvent e) {
			int x = e.getX();
			int y = e.getY();
			la.setLocation(x,y);
		}
}
	public static void main(String [] args) {
		new MouseListenerEx();
	}
}