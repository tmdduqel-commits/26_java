package day14;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class MouseListenerEx2 extends JFrame {
    private JLabel la = new JLabel("Hello");
    
    public MouseListenerEx2() {
        setTitle("Mouse 이벤트예제");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container con = getContentPane();
        
        // 이벤트 리스너 등록하기
        con.addMouseMotionListener(new MyMouseListener2());
        
        con.setLayout(null);
        la.setSize(50, 20);
        la.setLocation(30, 30);
        con.add(la);
        
        setSize(250, 250);
        setVisible(true);    
    }
    
    // 내부 클래스(Inner Class)로 마우스 리스너 객체 구현
    class MyMouseListener2 extends MouseMotionAdapter {
        
        @Override
        public void mouseDragged(MouseEvent e) {
            la.setText("MouseDragged(" + e.getX() + "," + e.getY() + ")");    
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            la.setText("MouseMoved(" + e.getX() + "," + e.getY() + ")");
        }
    } 

    public static void main(String[] args) {
        new MouseListenerEx2();
    }
}