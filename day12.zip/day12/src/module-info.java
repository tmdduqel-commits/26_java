module day12 {
	requires java.desktop;
}