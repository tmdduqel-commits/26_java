package my.app;
import java.util.HashMap;

public class HashMapEx {
	
	public static void main(String[] args) {
		HashMap<String,Integer> hm = new HashMap<String,Integer>();
		hm.put("홍길동",70);
		hm.put("이길동",100);
		hm.put("강길동",50);
		hm.put("박길동",90);
		
		System.out.println(hm.get("이길동"));
	}
}
