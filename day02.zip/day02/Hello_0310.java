package day02;

public class Hello_0310 {

	public static void main(String[] args) {
		// print계열 메소드를 이용해 자바로 하고싶은 것 작성해서 출력 하기.
		System.out.println("남성 의류 쇼핑몰을 해보고싶으므로\n자바를 다루는 것이"
				+ " 익숙해진다면 \n나의 쇼핑몰 사이트를 만들고싶다.");

	}

}
