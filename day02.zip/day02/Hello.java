package day02;

public class Hello {
	
	public static void main(String[] args) {
		
		//한줄 주석
		//System.out.println("Hello Java~!");
		//System.out.println("이름:여승엽");
		System.out.print("반갑습니다. 열심히 java 공부해요\n줄바꿨습니다.");
		System.out.print("반갑습니다. 열심히 java 공부해요\n줄바꿨습니다.");
		//System.out.println("학번:20221857");
		
		
	}

}
