package day02;

public class Data_Type_Test {

	public static void main(String[] args) {
		// 1. 기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 24;
		height = 177.5;
		weight = 67.5;
		
		
		
		// 2. 레퍼런스형 - 3개 (배열, 클래스, 인터페이스)
		String name = "여승엽";
		//name = "여승엽";
		String s = new String("홍길동");
				
		Data_Type_Test dtt = new Data_Type_Test();
		// 주소 addr
		String addr = "용운동 656 메트로젠 301호";
		
		
		
		// 3. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이:"+ age+"살");
		System.out.println("키:"+ height+"cm");
		System.out.println("몸무게:"+ weight+"kg");
		System.out.println("이름:"+ name);
		System.out.println("주소:"+addr);
		
		
	}

}
